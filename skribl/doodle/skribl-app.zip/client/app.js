(() => {
  const $ = sel => document.querySelector(sel);
  const $$ = sel => document.querySelectorAll(sel);

  // Elements
  const joinScreen = $("#join-screen");
  const game = $("#game");
  const nameInput = $("#name");
  const roomInput = $("#room");
  const genRoomBtn = $("#gen-room");
  const joinBtn = $("#join");

  const startBtn = $("#start");
  const statusEl = $("#status");
  const timerEl = $("#timer");
  const wordMaskEl = $("#word-mask");

  const canvas = $("#canvas");
  const ctx = canvas.getContext("2d");
  const colorInput = $("#color");
  const sizeInput = $("#size");
  const eraserBtn = $("#eraser");
  const clearBtn = $("#clear");
  const choicesBox = $("#word-choices");

  const playersBox = $("#players");
  const chatBox = $("#chat");
  const chatText = $("#chat-text");
  const sendBtn = $("#send");

  // State
  let ws = null;
  let myId = null;
  let isAdmin = false;
  let drawer = false;
  let drawing = false;
  let last = null;
  let strokeColor = "#000000";
  let strokeSize = 3;
  let roundEndAt = 0;
  let roomCode = null;
  let wordChoices = [];

  function randCode() {
    const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    let s = "";
    for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random()*chars.length)];
    return s;
  }

  genRoomBtn.addEventListener("click", () => {
    roomInput.value = randCode();
  });

  joinBtn.addEventListener("click", () => {
    const name = (nameInput.value || "").trim() || "Player";
    const room = (roomInput.value || "").trim().toUpperCase() || "LOBBY";
    roomCode = room;

    // UI
    joinScreen.classList.add("hidden");
    game.classList.remove("hidden");
    statusEl.textContent = `Room ${room}`;

    // Connect WS
    let proto = location.protocol === "https:" ? "wss" : "ws";
    const url = `${proto}://${location.host}`;
    ws = new WebSocket(url);
    ws.addEventListener("open", () => {
      ws.send(JSON.stringify({ type: "join", name, room }));
    });
    ws.addEventListener("message", onMessage);
  });

  function onMessage(ev) {
    let msg = null;
    try { msg = JSON.parse(ev.data); } catch(e) { return; }

    switch (msg.type) {
      case "joined":
        myId = msg.id;
        isAdmin = !!msg.isAdmin;
        if (isAdmin) startBtn.classList.remove("hidden");
        logSys(`Joined ${msg.room} as ${myId}${isAdmin ? " (admin)" : ""}`);
        break;

      case "system":
        logSys(msg.message || "");
        break;

      case "state":
        renderPlayers(msg.players, msg.drawerId);
        if (msg.round) {
          if (msg.round.word) {
            // I'm the drawer (server only sends actual word to drawer)
            drawer = true;
            statusEl.textContent = `You're drawing: "${msg.round.word}"`;
            wordMaskEl.textContent = "";
          } else {
            drawer = (msg.drawerId === myId);
            wordMaskEl.textContent = msg.round.maskedWord || "";
          }
          roundEndAt = msg.round.endAt || 0;
        }
        canvas.style.cursor = drawer ? "crosshair" : "not-allowed";
        break;

      case "chat":
        log(`${msg.from}`, msg.text);
        break;

      case "round":
        if (!msg.started) {
          timerEl.textContent = "";
          wordMaskEl.textContent = "";
          drawer = false;
          canvas.style.cursor = "not-allowed";
          break;
        }
        roundEndAt = msg.endAt || 0;
        wordMaskEl.textContent = msg.maskedWord || "";
        break;

      case "wordChoices":
        showWordChoices(msg.choices || []);
        break;

      case "drawer":
        drawer = !!msg.value;
        canvas.style.cursor = drawer ? "crosshair" : "not-allowed";
        break;

      case "stroke":
        drawSegment(msg.x0, msg.y0, msg.x1, msg.y1, msg.size, msg.color);
        break;

      case "clear":
        clearCanvas();
        break;

      case "pong":
        // ignore
        break;

      default:
        break;
    }
  }

  // UI helpers
  function renderPlayers(players, drawerId) {
    playersBox.innerHTML = "";
    for (const p of players) {
      const div = document.createElement("div");
      div.className = "player";
      const left = document.createElement("span");
      left.textContent = p.name + (p.id === drawerId ? " ✏️" : "");
      const right = document.createElement("span");
      right.textContent = `${p.score} ${p.guessed ? "✅" : ""}`;
      if (p.guessed) right.classList.add("guessed");
      div.appendChild(left);
      div.appendChild(right);
      playersBox.appendChild(div);
    }
  }

  function logSys(text) {
    const line = document.createElement("div");
    line.className = "line sys";
    line.textContent = text;
    chatBox.appendChild(line);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function log(from, text) {
    const line = document.createElement("div");
    line.className = "line";
    line.textContent = `${from}: ${text}`;
    chatBox.appendChild(line);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // Chat
  sendBtn.addEventListener("click", sendChat);
  chatText.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendChat();
  });

  function sendChat() {
    const text = chatText.value.trim();
    if (!text || !ws) return;
    ws.send(JSON.stringify({ type: "chat", text }));
    chatText.value = "";
  }

  // Timer
  setInterval(() => {
    if (!roundEndAt) { timerEl.textContent = ""; return; }
    const ms = Math.max(0, roundEndAt - Date.now());
    const s = Math.ceil(ms / 1000);
    const mm = String(Math.floor(s / 60)).padStart(2, "0");
    const ss = String(s % 60).padStart(2, "0");
    timerEl.textContent = `⏱️ ${mm}:${ss}`;
  }, 250);

  // Start button
  startBtn.addEventListener("click", () => {
    if (!ws) return;
    ws.send(JSON.stringify({ type: "startGame" }));
  });

  // Drawing tools
  colorInput.addEventListener("input", () => {
    strokeColor = colorInput.value;
  });
  sizeInput.addEventListener("input", () => {
    strokeSize = +sizeInput.value;
  });
  eraserBtn.addEventListener("click", () => {
    strokeColor = "#FFFFFF";
    colorInput.value = "#FFFFFF";
  });
  clearBtn.addEventListener("click", () => {
    if (!drawer || !ws) return;
    clearCanvas();
    ws.send(JSON.stringify({ type: "clear" }));
  });

  function canvasPoint(e) {
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);
    return { x, y };
  }

  function drawSegment(x0, y0, x1, y1, size, color) {
    ctx.lineWidth = size;
    ctx.lineCap = "round";
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
  }

  function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  clearCanvas();

  canvas.addEventListener("mousedown", (e) => {
    if (!drawer) return;
    drawing = true;
    last = canvasPoint(e);
  });
  canvas.addEventListener("mousemove", (e) => {
    if (!drawer || !drawing) return;
    const pt = canvasPoint(e);
    drawSegment(last.x, last.y, pt.x, pt.y, strokeSize, strokeColor);
    if (ws) {
      ws.send(JSON.stringify({
        type: "stroke",
        x0: last.x, y0: last.y, x1: pt.x, y1: pt.y,
        size: strokeSize, color: strokeColor
      }));
    }
    last = pt;
  });
  window.addEventListener("mouseup", () => drawing = false);

  // Word choices UI (for drawer)
  function showWordChoices(choices) {
    wordChoices = choices;
    choicesBox.innerHTML = "";
    const panel = document.createElement("div");
    panel.className = "panel";
    const h3 = document.createElement("h3");
    h3.textContent = "Choose a word";
    panel.appendChild(h3);
    const opts = document.createElement("div");
    opts.className = "opts";
    for (const w of choices) {
      const btn = document.createElement("button");
      btn.textContent = w;
      btn.addEventListener("click", () => {
        ws && ws.send(JSON.stringify({ type: "chooseWord", word: w }));
        choicesBox.classList.add("hidden");
        choicesBox.innerHTML = "";
      });
      opts.appendChild(btn);
    }
    panel.appendChild(opts);
    choicesBox.appendChild(panel);
    choicesBox.classList.remove("hidden");
  }

  // Ping
  setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "ping" }));
    }
  }, 10000);
})();
