# Skribl App

A lightweight, self-hosted Skribl-style multiplayer drawing & guessing game.

## Quick Start

```bash
# 1) Extract the zip
cd skribl-app

# 2) Install dependencies
npm install

# 3) Run the server (defaults to port 8080)
npm start
```

Open `http://localhost:8080` in your browser. Open multiple tabs or share your LAN IP with friends on the same network.

## Features
- Rooms (4-letter codes). Create or join any room.
- Realtime drawing with pen/eraser, size, and color.
- Round system with rotating drawer, word choices, and timer.
- Chat + automatic correct-guess detection (case-insensitive).
- Simple scoring for drawer and guessers.
- Programming-themed word list included (editable in `server/words.js`).

## Notes
- This is intentionally lightweight (no DB). All state lives in memory.
- For internet hosting, run on a VPS and open the port in your firewall.
- You can change PORT by setting env var: `PORT=3000 npm start`

Enjoy!
