/**
 * Simple word list (programming/tech leaning). Add/remove freely.
 */
module.exports = [
  "array","binary","pointer","compile","function","variable","promise","closure","recursion","database",
  "socket","server","client","router","package","kernel","buffer","thread","mutex","render","sprite",
  "shader","cookie","session","token","lambda","struct","class","object","string","integer","boolean",
  "python","javascript","golang","rust","lua","sql","index","cache","queue","stack","hash","tree","graph",
  "docker","nginx","http","websocket","zip","encryption","checksum","branch","commit","merge","lint"
];
