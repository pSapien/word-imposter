/* eslint-disable no-console */
const path = require("path");
const express = require("express");
const { WebSocketServer } = require("ws");
const { v4: uuidv4 } = require("uuid");

const app = express();
const PORT = process.env.PORT || 8080;

// Serve client
app.use(express.static(path.join(__dirname, "..", "client")));
const server = app.listen(PORT, () => {
  console.log(`[skribl] listening on http://localhost:${PORT}`);
});

// WebSocket server
const wss = new WebSocketServer({ server });

// In-memory data
const rooms = new Map(); // roomCode -> { players: Map<id, player>, drawerOrder: string[], drawerIndex: number, round: { word, endAt, started }, chat: [] }
const WORDS = require("./words");

function getRoom(code) {
  if (!rooms.has(code)) {
    rooms.set(code, {
      players: new Map(),
      drawerOrder: [],
      drawerIndex: -1,
      round: { word: null, endAt: 0, started: false },
      chat: []
    });
  }
  return rooms.get(code);
}

function broadcast(room, payload) {
  for (const p of room.players.values()) {
    if (p.ws.readyState === 1) {
      p.ws.send(JSON.stringify(payload));
    }
  }
}

function safeName(name) {
  const n = String(name || "").trim();
  return n.slice(0, 18) || "Player";
}

function maskWord(word) {
  if (!word) return "";
  return word.replace(/[A-Za-z0-9]/g, "_");
}

function chooseThreeWords() {
  const picks = new Set();
  while (picks.size < 3) {
    picks.add(WORDS[Math.floor(Math.random() * WORDS.length)]);
  }
  return [...picks];
}

function nextDrawer(room) {
  if (room.drawerOrder.length === 0) return null;
  room.drawerIndex = (room.drawerIndex + 1) % room.drawerOrder.length;
  const id = room.drawerOrder[room.drawerIndex];
  return room.players.get(id) || null;
}

function currentDrawer(room) {
  if (room.drawerIndex < 0) return null;
  const id = room.drawerOrder[room.drawerIndex];
  return room.players.get(id) || null;
}

function roomState(room, requesterId = null) {
  const drawer = currentDrawer(room);
  return {
    type: "state",
    players: [...room.players.values()].map(p => ({
      id: p.id,
      name: p.name,
      score: p.score,
      guessed: !!p.guessed
    })),
    drawerId: drawer ? drawer.id : null,
    round: {
      started: room.round.started,
      // Only reveal word to the drawer
      word: requesterId && drawer && requesterId === drawer.id ? room.round.word : null,
      maskedWord: room.round.started ? maskWord(room.round.word) : "",
      endAt: room.round.endAt
    }
  };
}

function ensureDrawerOrder(room) {
  // Keep drawerOrder in sync with players (stable where possible)
  room.drawerOrder = room.drawerOrder.filter(id => room.players.has(id));
  for (const id of room.players.keys()) {
    if (!room.drawerOrder.includes(id)) room.drawerOrder.push(id);
  }
  if (room.drawerIndex >= room.drawerOrder.length) room.drawerIndex = -1;
}

function startRound(room) {
  ensureDrawerOrder(room);
  const drawer = nextDrawer(room);
  if (!drawer) return;

  // Reset guesses
  for (const p of room.players.values()) p.guessed = false;

  room.round = { word: null, endAt: 0, started: false };

  // Offer 3 words to the drawer
  const choices = chooseThreeWords();
  drawer.ws.send(JSON.stringify({ type: "wordChoices", choices }));
  broadcast(room, { type: "system", message: `${drawer.name} is choosing a word…` });
  broadcast(room, roomState(room));
}

function beginDrawingPhase(room, word) {
  const ROUND_SECONDS = 90;
  room.round.word = word;
  room.round.started = true;
  room.round.endAt = Date.now() + ROUND_SECONDS * 1000;

  const drawer = currentDrawer(room);
  if (drawer) drawer.ws.send(JSON.stringify({ type: "drawer", value: true }));
  broadcast(room, { type: "round", started: true, endAt: room.round.endAt, maskedWord: maskWord(word) });
  broadcast(room, roomState(room));
}

function endRound(room, reason = "Time up!") {
  const drawer = currentDrawer(room);
  const word = room.round.word;
  room.round.started = false;
  broadcast(room, { type: "system", message: `Round over! The word was: "${word || "?"}" (${reason})` });
  broadcast(room, { type: "round", started: false });
  if (drawer) drawer.ws.send(JSON.stringify({ type: "drawer", value: false }));
  broadcast(room, roomState(room));
  // Brief pause then next round if enough players
  setTimeout(() => {
    if (room.players.size >= 2) startRound(room);
  }, 2000);
}

function scoreForGuess(room) {
  // Simple time-based scoring: max 100 -> min 20
  const remain = Math.max(0, room.round.endAt - Date.now());
  const pct = Math.min(1, remain / 90000);
  return Math.max(20, Math.round(20 + 80 * pct));
}

wss.on("connection", (ws) => {
  let room = null;
  let player = null;

  ws.on("message", (buf) => {
    let msg = null;
    try { msg = JSON.parse(buf.toString()); } catch(e) { return; }

    if (msg.type === "join") {
      const code = String(msg.room || "").trim().toUpperCase() || "LOBBY";
      room = getRoom(code);
      const id = uuidv4();
      player = {
        id,
        name: safeName(msg.name),
        ws, roomCode: code,
        score: 0,
        guessed: false,
        isAdmin: room.players.size === 0 // first to join becomes admin
      };
      room.players.set(id, player);
      ensureDrawerOrder(room);

      ws.send(JSON.stringify({ type: "joined", id, room: code, isAdmin: player.isAdmin }));
      broadcast(room, { type: "system", message: `${player.name} joined ${code}` });
      broadcast(room, roomState(room, player.id));
      return;
    }

    if (!room || !player) return;

    switch (msg.type) {
      case "chat": {
        const text = String(msg.text || "").slice(0, 200);
        if (!text) break;
        // If a round is active, check for correct guess (only for non-drawer who haven't guessed)
        const drawer = currentDrawer(room);
        const isDrawer = drawer && drawer.id === player.id;
        if (room.round.started && !isDrawer && !player.guessed) {
          if (room.round.word && text.toLowerCase().trim() === room.round.word.toLowerCase().trim()) {
            player.guessed = true;
            const pts = scoreForGuess(room);
            player.score += pts;
            // Drawer also gets small points
            if (drawer) drawer.score += Math.round(pts * 0.3);
            broadcast(room, { type: "system", message: `${player.name} guessed the word! (+${pts})` });
            broadcast(room, roomState(room));

            // If all guessers guessed, end round early
            const guessers = [...room.players.values()].filter(p => p.id !== drawer.id);
            const allGuessed = guessers.length > 0 && guessers.every(p => p.guessed);
            if (allGuessed) endRound(room, "Everyone guessed!");
            break;
          }
        }
        broadcast(room, { type: "chat", from: player.name, text });
        break;
      }

      case "startGame": {
        // Only admin can start, need at least 2 players
        if (player.isAdmin && room.players.size >= 2) {
          if (!room.round.started) startRound(room);
          else ws.send(JSON.stringify({ type: "system", message: "Round already in progress." }));
        } else {
          ws.send(JSON.stringify({ type: "system", message: "Need 2+ players; only admin can start." }));
        }
        break;
      }

      case "chooseWord": {
        // Only drawer can choose
        const drawer = currentDrawer(room);
        if (!drawer || drawer.id !== player.id) break;
        const word = String(msg.word || "").toLowerCase();
        if (!word) break;
        if (!WORDS.includes(word)) break;
        if (room.round.started) break; // already chosen
        beginDrawingPhase(room, word);
        break;
      }

      case "stroke": {
        // Only drawer can draw during round
        const drawer = currentDrawer(room);
        if (!drawer || drawer.id !== player.id) break;
        if (!room.round.started) break;
        const seg = {
          x0: +msg.x0, y0: +msg.y0, x1: +msg.x1, y1: +msg.y1,
          size: Math.max(1, Math.min(50, +msg.size || 3)),
          color: String(msg.color || "#000000")
        };
        // Broadcast to all other players
        for (const p of room.players.values()) {
          if (p.id === player.id) continue;
          if (p.ws.readyState === 1) p.ws.send(JSON.stringify({ type: "stroke", ...seg }));
        }
        break;
      }

      case "clear": {
        const drawer = currentDrawer(room);
        if (!drawer || drawer.id !== player.id) break;
        broadcast(room, { type: "clear" });
        break;
      }

      case "ping": {
        ws.send(JSON.stringify({ type: "pong", t: Date.now() }));
        break;
      }

      default:
        break;
    }
  });

  ws.on("close", () => {
    if (!room || !player) return;
    room.players.delete(player.id);
    for (let i = 0; i < room.drawerOrder.length; i++) {
      if (room.drawerOrder[i] === player.id) {
        room.drawerOrder.splice(i, 1);
        if (i <= room.drawerIndex) room.drawerIndex--;
        break;
      }
    }
    broadcast(room, { type: "system", message: `${player.name} left` });

    // If drawer left mid-round, end the round quickly
    const drawer = currentDrawer(room);
    if (!drawer || (drawer && drawer.id !== (room.round.drawerId || null))) {
      // no-op; drawer is derived live
    }
    if (room.round.started && (!drawer || drawer.id === player.id)) {
      endRound(room, "Drawer left.");
    } else {
      broadcast(room, roomState(room));
    }
  });
});

// Round timer monitor (server-side safety)
setInterval(() => {
  for (const room of rooms.values()) {
    if (room.round.started && Date.now() >= room.round.endAt) {
      endRound(room, "Time up!");
    }
  }
}, 1000);
